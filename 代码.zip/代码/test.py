import os
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torch
from torchvision import transforms

from model import CIFAR10Model

class TestDataset(Dataset):
    def __init__(self, img_dir, transform):
        self.img_dir = img_dir
        self.transform = transform
        self.filenames = sorted([f for f in os.listdir(img_dir) if f.endswith('.png')],
                                key=lambda x: int(os.path.splitext(x)[0]))

    def __len__(self):
        return len(self.filenames)

    def __getitem__(self, idx):
        fname = self.filenames[idx]
        img_path = os.path.join(self.img_dir, fname)
        image = Image.open(img_path).convert('RGB')
        image = self.transform(image)
        return image, fname

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

transform = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])

class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer',
               'dog', 'frog', 'horse', 'ship', 'truck']

model = CIFAR10Model().to(device)
model.load_state_dict(torch.load("best_model.pth"))
model.eval()

test_dir = "./test"
dataset = TestDataset(test_dir, transform)
loader = DataLoader(dataset, batch_size=64, shuffle=False)

predictions = []
with torch.no_grad():
    for images, filenames in loader:
        images = images.to(device)
        outputs = model(images)
        _, preds = torch.max(outputs, 1)
        for fname, pred in zip(filenames, preds):
            class_name = class_names[pred.item()]
            predictions.append((fname, class_name))

# 排序并写入
predictions.sort(key=lambda x: int(os.path.splitext(x[0])[0]))
with open("predictions.csv", "w") as f:
    f.write("id,label\n")
    for idx, (_, label) in enumerate(predictions):
        f.write(f"{idx+1},{label}\n")

print("Saved predictions.csv")
