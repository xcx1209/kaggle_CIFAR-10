import torch
import torchvision
from torch.nn import CrossEntropyLoss
from torch.utils.data import DataLoader
from torchvision import transforms
from torch.optim import SGD
from model import CIFAR10Model

if __name__ == '__main__':
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    #数据预处理
    #图像转化为张量，并归一化到[-1,1]
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5,))])

    #加载数据集
    trn_dataset = torchvision.datasets.CIFAR10(root='./data/train', download=True,transform=transform)
    tst_dataset = torchvision.datasets.CIFAR10(root='./data/train', train=False, download=True,transform=transform)

    #数据加载器
    batch_size = 64
    trn_loader = DataLoader(trn_dataset, batch_size=batch_size, shuffle=True)
    tst_loader = DataLoader(tst_dataset, batch_size=batch_size, shuffle=False)

    #设置损失函数和优化器
    model = CIFAR10Model().to(device) #将模型移到GPU
    sgd = SGD(model.parameters(), lr=0.01, weight_decay=1e-3)
    loss_fn = CrossEntropyLoss()

    #开始训练
    print('start training ...')

    total_epoch = 50
    prev_acc = 0.0
    save_path = "best_model.pth"
    for current_epoch in range(total_epoch):
        #训练阶段
        model.train()
        train_loss = 0.0
        correct_train = 0
        total_train = 0

        for idx, (trn_x, trn_y) in enumerate(trn_loader):
            trn_x = trn_x.to(device)
            trn_y = trn_y.to(device)

            sgd.zero_grad()#梯度清零
            trn_y_pred = model(trn_x)
            loss = loss_fn(trn_y_pred, trn_y)
            loss.backward()
            sgd.step()
            # 计算训练准确率
            _, predicted = torch.max(trn_y_pred.data, 1)
            total_train += trn_y.size(0)
            correct_train += (predicted == trn_y).sum().item()

            train_loss += loss.item()

        # 计算平均训练损失和准确率
        avg_train_loss = train_loss / len(trn_loader)
        train_acc = 100 * correct_train / total_train

        #模型验证
        model.eval()
        test_loss = 0.0
        correct_test = 0
        total_test = 0

        with torch.no_grad():  # 禁用梯度计算
            for idx, (tst_x, tst_y) in enumerate(tst_loader):
                tst_x = tst_x.to(device)
                tst_y = tst_y.to(device)

                tst_y_pred = model(tst_x)
                loss = loss_fn(tst_y_pred, tst_y)
                test_loss += loss.item()

                # 计算验证准确率
                _, predicted = torch.max(tst_y_pred.data, 1)
                total_test += tst_y.size(0)
                correct_test += (predicted == tst_y).sum().item()

            # 计算平均验证损失和准确率
        avg_test_loss = test_loss / len(tst_loader)
        test_acc = 100 * correct_test / total_test

    # 打印每个epoch的结果
    print(f'Epoch [{current_epoch + 1}/{total_epoch}] | '
          f'Train Loss: {avg_train_loss:.4f} | Train Acc: {train_acc:.2f}% | '
          f'Test Loss: {avg_test_loss:.4f} | Test Acc: {test_acc:.2f}%')

    # 保存最佳模型
    if test_acc > prev_acc:
        prev_acc = test_acc
        torch.save(model.state_dict(), save_path)

    print(f'Model saved with test accuracy: {test_acc:.2f}%')
